# Phase 2 dataset assessment

Reviewed September 9, 2026. These are candidates, not newly scored data. Coverage describes the source's intended scope; no complete ingestion or city-by-city completeness audit has yet been performed. Recommendations and proposed joins below are implementation judgments.

Keep the five existing weights and scores unchanged. Prefer one consistent regional or national source, one observation window, and explicit missing-data flags. All requested Maricopa communities are within the geographic scope of the national candidates; this does not guarantee complete records in every community.

## 1. Violent crime — defer block-group scoring

**Source:** [Arizona DPS Arizona Crime Online](https://azcrimestatistics.azdps.gov/), with [DPS counting guidance](https://azcrimestatistics.azdps.gov/faqs.aspx) and [FBI NIBRS documentation](https://ucr.fbi.gov/nibrs/nibrs_dcguide.pdf) as methodological references.

**Coverage:** Statewide reporting agencies, including Valley jurisdictions; reporting completeness must be established separately for each agency and month. **Updates:** DPS reports refresh nightly after submissions; the refresh date does not establish a complete incident period. **Granularity:** Public agency/time/offense reports. **Block-group join:** No defensible direct join established. Public incident location types are not usable street coordinates; distributing agency totals across block groups would invent local variation.

**Limitations / decision:** Reported offenses are not all crimes experienced. Agency boundaries, missing submissions, offense-versus-victim counting, revisions, and overlapping jurisdictions matter. Require a documented regional geocoded export with compatible definitions and complete reporting periods before proceeding. Do not combine unlike city dashboards or infer zero crime from no report.

## 2. Property crime — defer block-group scoring

**Source / coverage / updates / granularity:** The same [DPS regional reporting system](https://azcrimestatistics.azdps.gov/) and [counting guidance](https://azcrimestatistics.azdps.gov/faqs.aspx): statewide agency reports, nightly refresh, agency/time/offense aggregates. **Block-group join:** Not established; needs consistently geocoded incidents.

**Limitations / decision:** Burglary, theft, and motor-vehicle theft require a common definition and counting unit; the DPS guidance distinguishes incidents, offenses, victims, and vehicles. Residential population alone can distort comparisons around shopping, parking, and employment centers. Audit exposure denominators and duplicate incidents before using any neighborhood rate. Keep out of the composite until those issues are resolved.

## 3. Extreme heat — strongest next data pilot

**Source:** [USGS Landsat Collection 2 Level-2 surface temperature](https://www.usgs.gov/landsat-missions/landsat-collection-2-surface-temperature), also documented in the [Landsat 8 dataset catalog](https://developers.google.com/earth-engine/datasets/catalog/LANDSAT_LC08_C02_T1_L2).

**Coverage:** Global land observations, including the entire Valley. **Updates:** Ongoing scene acquisitions; aggregate comparable summer observations into an annual release rather than treating an individual overpass as current conditions. **Granularity:** 30-meter output grid, with coarser effective thermal detail. **Block-group join:** Yes, spatial zonal statistics with valid-pixel coverage recorded.

**Limitations / proposal:** Surface temperature is not air temperature or a heat-health forecast. Cloud/shadow effects, emissivity gaps, changing vegetation, and daytime-only retrievals need quality filtering. Compare consistent seasons and dates; disclose sample counts and missing pixels. Pilot a separate summer surface-heat overlay and assess residential exposure before proposing a weight.

## 4. Parks and green-space access — inventory audit first

**Source:** [USGS Protected Areas Database (PAD-US)](https://www.usgs.gov/programs/gap-analysis-project/science/pad-us-data-overview), [4.x data release](https://doi.org/10.5066/P96WBCHS). The official overview cites PAD-US 4.1 (2024).

**Coverage:** National; all federal and most state/local protected lands, including the Valley. **Updates:** Versioned releases, not live; recent major versions were 2020, 2022, and 2024. Individual source vintages vary. **Granularity:** Park/protected-land polygons and access attributes. **Block-group join:** Yes, polygon intersection; meaningful access additionally requires entrances and a pedestrian network.

**Limitations / proposal:** Conservation land is not necessarily a usable neighborhood park. Access is often categorically assigned, and small municipal parks may be incomplete. Deduplicate overlapping boundaries, exclude closed access, check park inventories across every requested city, and audit entrances. Measure walking access to usable parks, not simply protected acreage inside a large block group.

## 5. Grocery access — screen and validate retailer points

**Source:** [USDA SNAP Retailer Locator](https://www.fna.usda.gov/snap/retailer-locator) and [historical downloads](https://www.fna.usda.gov/snap/retailer-locator/data).

**Coverage:** Authorized SNAP retailers nationally, including all Valley communities. **Updates:** Current locator plus historical snapshots; the historical page identifies a December 31, 2025 snapshot. A guaranteed current-feed refresh interval was not verified; inspect timestamps before use. **Granularity:** Store locations. **Block-group join:** Yes, point containment for counts; use distances to stores outside the block group as well when measuring access.

**Limitations / proposal:** SNAP authorization is not a full-service grocery designation. Filter appropriate store types, exclude unsuitable outlets, check closures and coordinates, and audit non-SNAP supermarkets omitted by this source. It does not directly measure prices, fresh-food inventory, or accessible walking routes. Use store facts only, never benefit-recipient demographics, in a future access measure.

## 6. Public transit access — best near-term accessibility source

**Source:** [Valley Metro developer resources](https://www.valleymetro.org/contact/developers-resources) (official static and real-time GTFS for bus/light rail).

**Coverage:** Regional services represented in the feed. A municipality without a listed stop may have demand-response or another service absent from static GTFS; audit western Valley coverage before labeling it unserved. **Updates:** Schedule/feed revisions; no guaranteed cadence verified. Use the actual feed calendar and valid service dates. **Granularity:** Stops, routes, trips, stop times, calendars. **Block-group join:** Yes, stops and walking-distance catchments aggregated to block groups.

**Limitations / proposal:** Count scheduled departures within a walkable distance on a representative weekday and weekend, not only stop density. Avoid counting both directions or duplicate feed exports twice. Scheduled service is not reliability; walking barriers, accessibility, service spans, and demand-response gaps require separate flags. Archive each feed and its effective dates.

## 7. Walkability — useful dated reference overlay

**Source:** [EPA National Walkability Index / Smart Location Mapping](https://www.epa.gov/smartgrowth/smart-location-mapping), [June 2021 methodology](https://www.epa.gov/sites/default/files/2021-06/documents/national_walkability_index_methodology_and_user_guide_june2021.pdf).

**Coverage:** Nationwide block groups, including the Valley. **Updates:** Periodic; 2021 is the documented dataset/methodology revision, not an annually refreshed product. **Granularity:** Census block groups; national index 1–20. **Block-group join:** Possible only after confirming source geography vintage and crosswalking changed boundaries; do not assume identical GEOIDs mean identical polygons.

**Limitations / proposal:** The index uses intersections, transit proximity, and land-use mix. It does not directly audit sidewalks, crossings, shade, heat, or pedestrian safety. Fast-growing areas may be stale. Retain the source scale/date in a context layer. Avoid double-counting transit access if both enter a later composite; select built-environment fields only from the larger SLD.

## Recommended sequence and acceptance criteria

Build a separate summer surface-heat overlay next: it adds a locally important physical condition beyond income and housing. Transit frequency is the strongest subsequent access pilot. Validate parks and grocery completeness before comparison scores. Keep crime deferred.

Before any new weight: freeze sources and dates, quantify coverage for each requested community, validate spatial joins against authoritative geometry, inspect extreme/missing values, test sensitivity and correlated inputs, and publish proposed normalization and uncertainty. A single point, centroid, or coarse-area statistic should never masquerade as a measured block-group average. Continue excluding protected demographic characteristics.
